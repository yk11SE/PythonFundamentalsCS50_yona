# Demonstrates addition

x = 1
y = 2

z = x + y

print(z)
