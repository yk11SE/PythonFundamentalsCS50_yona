# Demonstrates concatenation of strings

name = input("What's your name? ")
print("hello, " + name)
